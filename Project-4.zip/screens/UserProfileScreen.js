import React from 'react'
import { View } from 'react-native'

const UserProfileScreen = () => {
  return (
    <View>
      
    </View>
  )
}

export default UserProfileScreen
